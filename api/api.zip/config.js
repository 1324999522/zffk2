
// 修改配置 需要重启服务才能生效
module.exports = {
    mysql: {

        database: 'zf00001',
        username: 'zf00001',
        password: 'a1324999522',

        // 默认连接本地数据库
        host: '175.24.41.149',
    },
    JWT_SECRET_KEY: 'cong',
    // 系统管理员ID
    system_admin_id: 19,
    domain: 'localhost',
    link: '769920',
    // 注册
    register: {
        allow: false,
    },
    directLoginApp:true,
    directLoginAppUrl:'http://192.168.1.6:9500',
    baidu_cookie: true,
    // 收款
    collect: {
        notify_url: 'https://bolikuaiyin.yicp.fun/client/order/pay/success',
        ali_pay: {
            show: true,
            appid: '2018032302431243',
            private_key: `MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCGl6xwRw7ER6u+qvbEz2OGRhTW0zCqkKWy97n0uiTrlsCBXZYId6TDGo0eDXYV8jfueisIHpE0/6UZeUBEf79QRdkzdKxMYOnrR1G6h/l/w70r6rN1SdM7W1K4NETPx/aFjCnua4FiEtsIKjftm/24qLKsHv8m4QkjinnwZgXoY21bDCCRgeP4dpvqEaAUc+n2OAh9eRg9bPuY2gOrcTmHGFQkeszNm0zujrRsRviMp1udw/NNeausLpF71xrIQ6GDvT406RbGC+eRaRAkDx8u2hV2FXLgclzcY/ExRWxKvM3kqOTxZYzFZrNjNA+283WZJnovMwUM8COw+xjwPHo1AgMBAAECggEAQE4XRU2t8HmNxPtKC55Knsy9CCa/Cb8ya9+QKS0GlsjgEO71z/XZ8p2s7r7fvHyN3JLiHG7+UaQS7ajQ2+ltLp0wuTT1XUiweokIs2Zj/nc22tS4CUHMen+XdgsDFYMkdYoSPqd+ma0ImU4SiqQNBT0UoMfugFTkWObAe+tCx1SIOtjh49jLvezVR8XdPWrtbAJpWsyeGLUncKKK2E5/0ViRZeZ6nkh4oQlEkSsDQN4lrOkOd1Iqu4GNg6tspcwu4hOCvHd4xt2trENBsiLRw+zUmJoEwsoqbx1WYhHMKt0+7msvJsdLskacrw6/1SzPr4LGKzjSw3JW/ExE8CjrwQKBgQDDxH9mjnpi/cE9tngGXdeHpJVEGmmm+eX/J1HhbvuvRXJ8/eEh6Yk4pMBYeAB0fuOFMyWJ7GmSL4pA+W3PKPpuX7qLd19f5oJVUkd6iTz/A87gghwI0+GGLKIdfEjtBrv8L4jk5b4PAWVPXJf9CaT3+zApRDlqTfXiJWZl0o2eNwKBgQCwAMKl5Llpgkp3zZshE9A6XUeMB5LWE5+T4IKLto/EVqPbFnIobpNlcfMz1xuSvQrQs33gi9VZFK0i0CvxFwm3qv1LqQw46hSWe22aZpb3bil8VQxnU/+HVpw9JYyJPBPWc8RSDIRpzcwolzHcwApMMzL3dWICYUYsO+OzRqUU8wKBgBszaEhFr7elbn42pkKsM1BDjAHkcZ2jx1NGkVfzZcEasyeu1uMxYcGfEqK4Ocf2AYL2clbRpHGNbXZNsfZAyVsgrfjG41ed3aohPpFGFFWSn+IN8ftABWvxM61JIZDdiK0npau4SEopdXwrb2rXNjbGjhCNzDR7FJkRfULUmJzNAoGBAKZUYZ+Dk5HZluS3g0Z0QhIWO1pjgeoca2/F+bltk1p6gqm3AbWiIlv5n1w7ioxXaVQofOprW/mup5zB3PUfz4gq6OvK24kh9sjr5n3HPB6jlkMw4OL5qABP4qGKzdCX3SuLBlqAB9cxrSIjGPVE67ZtoFnqLfCP21BMXPj851/vAoGAfSV0GHmG6pxHG0Pits/SiVqvbB3K4G9KXHqmkEbB1aML0G97qJaINd6CyYmxx7VCmkPpF9GbO+awQuTUtJXxqGTq9AZoHGRtVsSDQLlMVFqEVMTeCi07jHDZgNAzLHsCYffdaOA6XS7DF4jPbTRcEiGPO90vryTovmEVu1L2j94=`,
        },
        wx_pay: {
            show: false,
            appid: 'wxf3d37679488f0b35',
            mch_id: '1614796794',
            serial_no: '169267D02FDE7C3936EE1D6F2017375EB98F2CAF',
            apiv3_private_key: 'Aa132499952213249995221324999522',
            private_key: `-----BEGIN PRIVATE KEY-----
            MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDL2asB2OyozOdq
            HJUGuGGbwCs6vg6RArkH5re+jMiNpi3AitgPcYVn63VRnJso9pf7L99qQxCgdhNZ
            btSuFiXNu6W7mEcq/blKkfUEaWP5oGRjFrUMRmbzdbIX3EfRZZjudYnuLAbHEJOF
            kRNaLN01Dh8dIB3l7HUn+34keNauW1BylATkOETHjLqr+8xtbpwxcpvF5CVm/UmL
            6I7Uwm1Jvexmd5mWaDt7qsox7Q4cm3A9HBRohhnc714HsCP5o9SYEHH2F2FAt7eX
            vaMWDgMN+7vCZWs72xkGpAqmSEX6l0VdaPudWlzcxhWRt2SI2Y4w4JnRJ23mTOl7
            56x2QBeDAgMBAAECggEAWCjn6yGcoBgV0O9RiBl/pTNDvuDpPc+WpBMkzhTmu1Pu
            H4IslOk8j8fl8givldSnv+thTPx6GVtXXOswsaVEbihEMdBWnwIh+10KQQEvSosS
            P0RXwlpENfBluCn9KVMuA5rzrvx9ZeQGWNJ4MxyKAmL8E8WLCJ/tvv/l+vIDrl1r
            wq4GxJuDpNg5w7cnQzfM+Kziv0DNuEKUrFKZEryE8C9zgF+a5GA63T6TJYj5R/AT
            ljW1X0s+c9jGC1/SIgvsKHL26Z4PC+VssnqsfuqWhtyJDR+qB8layOoqxvpOCUF6
            5XrxYnqYtD0dN0rw3CAG8cET72SVgKN8l3saLkvSUQKBgQDssR9l9OL3EZmS6YbN
            NQopQh/YiEUHb5p7lnDORbhBjhLtMXM8tX+Yl1uBfV4+JfGTjvmYTpUjWW6s/Pev
            38Qt1MaekKqawdYv9kV4+SdjLt5q4zrfFQILGCKYBs5zP+O5X1Smlw7McjSNQBut
            BG8V6hBMuLFb0xthhAF+dJl52wKBgQDcerVJlXN8qC1H+BBeiKuMgDE2lK/mLs4N
            uiaaa/ZZGsO9LJbKZ0C1DSPvVKAqNtWLzZ5LB4A+Q8dFL9gZChynM7qytA9CRgKJ
            hPOLdO2Vlr0kRhTw5uoVgduL/j25AnCGxbFZbbI0XIi4074zUjmT7RsEt1eYzCVt
            BosJ6P4teQKBgGu3G8Ppk1S/JLXQIvHGfo5SMm33bfq5VoOB7mphHj5vKrvZMklh
            i+TklNc0N6xu1ibB/WLL+GEy9QQyx4G5gu0clRtaWNm+9vuyxuEL+lnP3ZalPIiD
            Zf+ohy3Kgy+91qPo93ws6KYwHyxdDXtKtkcx0yMnNkfEpgRV79wdsi7bAoGBAIRs
            w2RN+o596KyYZySQjBEYkfaJedkUdbiy/Sq0+8LrG3QNSwiI2cmk+ddvCcAxLTQK
            LTA9ch5z0UVSBkaL10fp/xIEqkGREUcN7sXtViIJ5tLZsQw8dY6zb213KBVuTK32
            IZ5oD6f5iDkTHONwWJrrx9WeVWO2AiiozGwIYFppAoGBAJVFRdQJr8t7oBDG2bXy
            806Zsb5hlV1V50j7NE6fRdeZf/LM08dRro9QBcXc1VLpL6g2+sc5gEmRcvKUoWKp
            /fVMfaMv+90hMyPguUl6cyQoww7oE8DoL4dwv8HTF3khqVBKYceN8fa0c/j9+R45
            vHG4VxPNKsS058fwsrETEZnY
            -----END PRIVATE KEY-----`,
        }
    }
}

